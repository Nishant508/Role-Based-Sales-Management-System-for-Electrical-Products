import React, { useState } from 'react';
import { Plus, Trash2, Send } from 'lucide-react';

export default function NewQueryForm() {
  // Replace these with your existing state variables!
  const [equipments, setEquipments] = useState([{ type: 'Laptop', qty: 1, backup: 2 }]);

  return (
    <div className="bg-[#1e293b] rounded-xl shadow-lg border border-slate-700 overflow-hidden">
      <div className="p-6 border-b border-slate-700 flex justify-between items-center bg-blue-600/10">
        <div>
          <h2 className="text-xl font-bold text-white">New Customer Query</h2>
          <p className="text-sm text-slate-400">Power Requirement Analysis & UPS Recommendation</p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        {/* Top Details */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Location</label>
            <input 
              type="text" 
              placeholder="e.g. Chennai" 
              className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 focus:ring-1 focus:ring-blue-500 transition-all"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-300 mb-2">Region</label>
            <select className="w-full bg-slate-800 border border-slate-600 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-blue-500 appearance-none">
              <option>Select Region</option>
              <option>South</option>
              <option>North</option>
              <option>East</option>
              <option>West</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2 mt-2">
          <input type="checkbox" id="directKVA" className="w-4 h-4 rounded bg-slate-800 border-slate-600 text-blue-600 focus:ring-blue-600 focus:ring-offset-slate-900" />
          <label htmlFor="directKVA" className="text-sm text-slate-300">Customer provided KVA directly</label>
        </div>

        {/* Equipment List */}
        <div className="bg-[#0f172a] p-4 rounded-lg border border-slate-700 space-y-4">
          <h3 className="text-sm font-semibold text-slate-300 uppercase tracking-wider">Equipment List</h3>
          
          {equipments.map((eq, index) => (
            <div key={index} className="flex flex-wrap md:flex-nowrap items-end gap-4">
              <div className="flex-1">
                <label className="block text-xs text-slate-400 mb-1">Equipment</label>
                <select className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500">
                  <option>Laptop</option>
                  <option>Desktop</option>
                  <option>Server</option>
                </select>
              </div>
              <div className="w-24">
                <label className="block text-xs text-slate-400 mb-1">Quantity</label>
                <input type="number" defaultValue={eq.qty} className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500" />
              </div>
              <div className="w-32">
                <label className="block text-xs text-slate-400 mb-1">Backup (hrs)</label>
                <input type="number" defaultValue={eq.backup} className="w-full bg-slate-800 border border-slate-600 rounded-lg px-3 py-2 text-white focus:outline-none focus:border-blue-500" />
              </div>
              <button className="bg-red-500/10 text-red-500 hover:bg-red-500 hover:text-white p-2.5 rounded-lg transition-colors border border-red-500/20">
                <Trash2 size={18} />
              </button>
            </div>
          ))}

          <button className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 transition-colors mt-2">
            <Plus size={16} /> Add Equipment
          </button>
        </div>

        {/* Query Summary Box */}
        <div className="bg-gradient-to-br from-blue-900/40 to-slate-900 p-6 rounded-lg border border-blue-800/50">
          <h3 className="text-lg font-semibold text-white mb-4">Query Summary</h3>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between border-b border-slate-700/50 pb-2"><span className="text-slate-400">Location:</span> <span className="text-white font-medium">—</span></div>
            <div className="flex justify-between border-b border-slate-700/50 pb-2"><span className="text-slate-400">Final Capacity:</span> <span className="text-white font-medium">— kVA</span></div>
            <div className="flex justify-between border-b border-slate-700/50 pb-2"><span className="text-slate-400">Suggested UPS:</span> <span className="text-emerald-400 font-medium">Calculating...</span></div>
            <div className="flex justify-between pt-1"><span className="text-slate-400">Estimated Price:</span> <span className="text-xl font-bold text-white">₹ —</span></div>
          </div>
          
          <button className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-medium py-3 rounded-lg flex justify-center items-center gap-2 transition-colors shadow-lg shadow-blue-900/20">
            <Send size={18} /> Share Query
          </button>
        </div>

      </div>
    </div>
  );
}