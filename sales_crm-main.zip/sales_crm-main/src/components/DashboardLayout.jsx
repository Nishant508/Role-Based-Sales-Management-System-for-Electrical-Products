import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Package, Calculator, Zap, LogOut, Search, Bell, Moon, 
  Inbox, Battery, Server, Users, FileText, BarChart3, TrendingUp, MapPin, 
  Clock, Sparkles, X, ChevronRight
} from 'lucide-react';
import { useNavigate, useLocation } from 'react-router-dom';
import { auth, db } from "../firebase";
import { signOut } from "firebase/auth";
import { collection, onSnapshot, query, orderBy, limit } from "firebase/firestore";

export default function DashboardLayout({ children }) {
  const navigate = useNavigate();
  const location = useLocation();
  const currentPath = location.pathname;

  const user = auth.currentUser;
  const userEmail = user?.email || "guest@8vdigital.com";
  const displayName = userEmail.split('@')[0];
  const userInitials = displayName.substring(0, 2).toUpperCase();

  // --- STATE ---
  const [notifications, setNotifications] = useState([]);
  const [showNotifications, setShowNotifications] = useState(false);

  // --- 🛰️ LIVE NOTIFICATION FETCH ---
  useEffect(() => {
    // Get the 5 most recent leads to show in the dropdown
    const q = query(collection(db, "leads"), orderBy("createdAt", "desc"), limit(5));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const newNotifications = snapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      }));
      setNotifications(newNotifications);
    });

    return () => unsubscribe();
  }, []);

  // Role Logic
  let activeRole = 'sales'; 
  if (['/admin', '/catalog', '/users'].includes(currentPath)) activeRole = 'admin';
  else if (['/customer', '/invoices', '/tracking'].includes(currentPath)) activeRole = 'customer';
  else if (['/management', '/reports', '/regional'].includes(currentPath)) activeRole = 'management';

  return (
    <div className="flex h-screen bg-[#f8fafc] text-slate-900 font-sans overflow-hidden">
      
      {/* Sidebar */}
      <div className="w-64 bg-white border-r border-slate-200 flex flex-col z-20">
        <div className="p-6 flex items-center gap-3">
          <div className="bg-[#10b981] p-2 rounded-xl shadow-sm"><Zap size={22} className="text-white" /></div>
          <div>
            <h1 className="font-bold text-lg text-slate-800">8V Electric</h1>
            <p className="text-[10px] uppercase tracking-widest text-slate-400 font-bold">Power Solutions</p>
          </div>
        </div>
        
        {/* Role Switcher */}
        <div className="px-4 py-2 space-y-2">
          <div className="bg-slate-100 p-1 rounded-xl flex gap-1 border border-slate-200">
            <button onClick={() => navigate('/admin')} className={`flex-1 py-1.5 rounded-lg text-[10px] font-black ${activeRole === 'admin' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>ADMIN</button>
            <button onClick={() => navigate('/sales')} className={`flex-1 py-1.5 rounded-lg text-[10px] font-black ${activeRole === 'sales' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>SALES</button>
          </div>
          <div className="bg-slate-100 p-1 rounded-xl flex gap-1 border border-slate-200">
            <button onClick={() => navigate('/customer')} className={`flex-1 py-1.5 rounded-lg text-[10px] font-black ${activeRole === 'customer' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>CLIENT</button>
            <button onClick={() => navigate('/management')} className={`flex-1 py-1.5 rounded-lg text-[10px] font-black ${activeRole === 'management' ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-500'}`}>MGMT</button>
          </div>
        </div>

        <nav className="flex-1 mt-6 px-3 space-y-1 overflow-y-auto">
          {activeRole === 'admin' && (
            <><p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">System Admin</p>
              <NavItem icon={<LayoutDashboard size={18}/>} label="Control Center" active={currentPath === '/admin'} onClick={() => navigate('/admin')} />
              <NavItem icon={<Server size={18}/>} label="Product Catalog" active={currentPath === '/catalog'} onClick={() => navigate('/catalog')} />
              <NavItem icon={<Users size={18}/>} label="User Management" active={currentPath === '/users'} onClick={() => navigate('/users')} /></>
          )}
          {activeRole === 'sales' && (
            <><p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Sales Hub</p>
              <NavItem icon={<LayoutDashboard size={18}/>} label="Sales Hub" active={currentPath === '/sales'} onClick={() => navigate('/sales')} />
              <NavItem icon={<Inbox size={18}/>} label="My Leads" active={currentPath === '/user-dashboard'} onClick={() => navigate('/user-dashboard')} />
              <NavItem icon={<Calculator size={18}/>} label="KVA Calculator" active={currentPath === '/kva-calc'} onClick={() => navigate('/kva-calc')} />
              <NavItem icon={<Battery size={18}/>} label="Battery Calculator" active={currentPath === '/battery-calc'} onClick={() => navigate('/battery-calc')} />
              <NavItem icon={<Sparkles size={18}/>} label="AI Recommender" active={currentPath === '/recommendation'} onClick={() => navigate('/recommendation')} /></>
          )}
          {activeRole === 'customer' && (
            <><p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Client Portal</p>
              <NavItem icon={<LayoutDashboard size={18}/>} label="My Dashboard" active={currentPath === '/customer'} onClick={() => navigate('/customer')} />
              <NavItem icon={<Clock size={18}/>} label="Order Tracking" active={currentPath === '/tracking'} onClick={() => navigate('/tracking')} />
              <NavItem icon={<FileText size={18}/>} label="My Invoices" active={currentPath === '/invoices'} onClick={() => navigate('/invoices')} /></>
          )}
          {activeRole === 'management' && (
            <><p className="px-4 text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">Executive View</p>
              <NavItem icon={<BarChart3 size={18}/>} label="Exec Dashboard" active={currentPath === '/management'} onClick={() => navigate('/management')} />
              <NavItem icon={<TrendingUp size={18}/>} label="Revenue Reports" active={currentPath === '/reports'} onClick={() => navigate('/reports')} />
              <NavItem icon={<MapPin size={18}/>} label="Regional Data" active={currentPath === '/regional'} onClick={() => navigate('/regional')} /></>
          )}
        </nav>

        <div className="p-4 border-t border-slate-100">
          <button onClick={() => signOut(auth).then(() => navigate('/'))} className="w-full flex items-center gap-3 px-3 py-2 text-red-500 hover:bg-red-50 rounded-xl font-bold text-sm transition-all"><LogOut size={18}/> Sign Out</button>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-20 border-b border-slate-200 flex items-center justify-between px-8 bg-white z-30">
          <div className="flex items-center gap-4 bg-slate-50 px-4 py-2 rounded-2xl w-96 border border-slate-200"><Search size={18} className="text-slate-400" /><input type="text" placeholder="Search data..." className="bg-transparent text-sm outline-none w-full" /></div>
          
          <div className="flex items-center gap-6 relative">
            {/* 🔔 FUNCTIONAL NOTIFICATION BELL */}
            <div className="relative">
              <button 
                onClick={() => setShowNotifications(!showNotifications)}
                className={`p-2 rounded-xl transition-all ${showNotifications ? 'bg-blue-50 text-blue-600' : 'text-slate-400 hover:bg-slate-50'}`}
              >
                <Bell size={20} className={notifications.length > 0 && !showNotifications ? "animate-bounce" : ""} />
                {notifications.length > 0 && (
                  <span className="absolute top-1 right-1 bg-red-500 text-white text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-white shadow-sm">
                    {notifications.length}
                  </span>
                )}
              </button>

              {/* Notification Dropdown */}
              {showNotifications && (
                <div className="absolute right-0 mt-4 w-80 bg-white rounded-[24px] shadow-2xl border border-slate-200 overflow-hidden z-50 animate-in fade-in zoom-in duration-200">
                  <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
                    <p className="text-xs font-black text-slate-800 uppercase tracking-widest">Recent Activity</p>
                    <button onClick={() => setShowNotifications(false)} className="text-slate-400 hover:text-slate-600"><X size={16}/></button>
                  </div>
                  <div className="max-h-96 overflow-y-auto">
                    {notifications.length === 0 ? (
                      <div className="p-8 text-center text-slate-400 text-sm font-bold">No new activity</div>
                    ) : (
                      notifications.map((n) => (
                        <div key={n.id} onClick={() => {navigate('/user-dashboard'); setShowNotifications(false);}} className="p-4 border-b border-slate-50 hover:bg-blue-50/50 cursor-pointer transition-colors flex items-start gap-3 group">
                          <div className="bg-blue-100 p-2 rounded-lg text-blue-600 group-hover:bg-blue-600 group-hover:text-white transition-all"><Zap size={14}/></div>
                          <div className="flex-1">
                            <p className="text-xs font-black text-slate-800">{n.clientName || "New Lead Sync"}</p>
                            <p className="text-[10px] font-bold text-slate-500 mt-0.5">Requirement: {n.kvaRequirement} kVA</p>
                            <p className="text-[9px] text-blue-500 font-black mt-1 uppercase tracking-tighter">{n.type || "CRM SYNC"}</p>
                          </div>
                          <ChevronRight size={14} className="text-slate-300 mt-2" />
                        </div>
                      ))
                    )}
                  </div>
                  <button onClick={() => navigate('/user-dashboard')} className="w-full p-4 bg-slate-50 text-blue-600 text-[10px] font-black uppercase tracking-widest hover:bg-slate-100 transition-all">View All Pipeline</button>
                </div>
              )}
            </div>

            <div className="flex items-center gap-3 pl-6 border-l border-slate-100">
              <div className="text-right">
                <p className="text-sm font-black text-slate-800 leading-none">{userEmail.split('@')[0]}</p>
                <p className="text-[10px] font-bold text-slate-400 mt-1 uppercase tracking-tighter">{activeRole} Mode</p>
              </div>
              <div className="h-10 w-10 bg-slate-900 rounded-full flex items-center justify-center text-white font-black text-xs shadow-md">{userInitials}</div>
            </div>
          </div>
        </header>

        {/* Overlay to close notifications when clicking outside */}
        {showNotifications && <div className="fixed inset-0 z-40" onClick={() => setShowNotifications(false)}></div>}

        <main className="flex-1 overflow-y-auto p-8 relative z-10">{children}</main>
      </div>
    </div>
  );
}

function NavItem({ icon, label, active, onClick }) {
  return (
    <button onClick={onClick} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl font-bold text-sm transition-all relative group ${active ? 'bg-blue-50 text-blue-700' : 'text-slate-500 hover:bg-slate-50 hover:text-slate-700'}`}>
      {active && <div className="absolute left-0 w-1 h-6 bg-blue-600 rounded-r-full" />}
      <span className={active ? 'text-blue-600' : 'text-slate-400 group-hover:text-slate-600'}>{icon}</span>
      {label}
    </button>
  );
}