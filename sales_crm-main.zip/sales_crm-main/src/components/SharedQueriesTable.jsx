import React from 'react';
import { FileText, Download } from 'lucide-react';

export default function SharedQueriesTable() {
  // Dummy data for the presentation
  const queries = [
    { id: 'Q-1042', location: 'Chennai', region: 'South', capacity: '10 kVA', ups: 'Modular UPS 15kVA', price: '₹1,45,000', date: '2026-04-06' },
    { id: 'Q-1043', location: 'Mumbai', region: 'West', capacity: '5 kVA', ups: 'Line Interactive 5kVA', price: '₹45,000', date: '2026-04-05' },
    { id: 'Q-1044', location: 'Delhi', region: 'North', capacity: '20 kVA', ups: 'Online Double Conversion', price: '₹2,80,000', date: '2026-04-02' },
  ];

  return (
    <div className="mt-8 bg-[#1e293b] rounded-xl shadow-lg border border-slate-700 overflow-hidden">
      <div className="p-6 border-b border-slate-700 flex justify-between items-center bg-slate-800/30">
        <div>
          <h2 className="text-xl font-bold text-white">My Shared Queries</h2>
          <p className="text-sm text-slate-400">Recent customer power requirement analyses</p>
        </div>
      </div>
      <div className="overflow-x-auto">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="text-xs uppercase bg-[#0f172a] text-slate-400 border-b border-slate-700">
            <tr>
              <th className="px-6 py-4 font-semibold">Query ID</th>
              <th className="px-6 py-4 font-semibold">Location</th>
              <th className="px-6 py-4 font-semibold">Capacity</th>
              <th className="px-6 py-4 font-semibold">Suggested UPS</th>
              <th className="px-6 py-4 font-semibold">Est. Price</th>
              <th className="px-6 py-4 font-semibold">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/50">
            {queries.map((q, i) => (
              <tr key={i} className="hover:bg-slate-800/50 transition-colors">
                <td className="px-6 py-4 font-medium text-blue-400">{q.id}</td>
                <td className="px-6 py-4">{q.location} <span className="text-xs text-slate-500 block">{q.region}</span></td>
                <td className="px-6 py-4">{q.capacity}</td>
                <td className="px-6 py-4">{q.ups}</td>
                <td className="px-6 py-4 font-medium text-white">{q.price}</td>
                <td className="px-6 py-4 flex gap-2">
                  <button className="p-1.5 bg-blue-500/10 text-blue-400 rounded hover:bg-blue-500 hover:text-white transition-colors" title="View Details"><FileText size={16}/></button>
                  <button className="p-1.5 bg-slate-700 text-slate-300 rounded hover:bg-slate-600 transition-colors" title="Download PDF"><Download size={16}/></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}