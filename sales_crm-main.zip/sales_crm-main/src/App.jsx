import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { auth } from "./firebase";
import { onAuthStateChanged } from "firebase/auth";

// Auth & Dashboards
import Login from "./pages/Login";
import AdminDashboard from "./pages/AdminDashboard";
import UserDashboard from "./pages/UserDashboard";
import SalesDashboard from './pages/SalesDashboard'; 
import CustomerDashboard from './pages/CustomerDashboard';
import ManagementDashboard from './pages/ManagementDashboard';

// Tools
import KVACalculator from './pages/KVACalculator';
import BatteryCalculator from './pages/BatteryCalculator';
import RecommendationEngine from './pages/RecommendationEngine';
import UserManagement from './pages/UserManagement';
import RevenueReports from './pages/RevenueReports';
import MyInvoices from './pages/MyInvoices';
import ProductCatalog from './pages/ProductCatalog';
import DemoPlaceholder from './pages/DemoPlaceholder';

// 🛡️ SECURITY GUARD: Kicks unauthenticated users back to Login
function ProtectedRoute({ user, children }) {
  if (!user) {
    return <Navigate to="/" replace />;
  }
  return children;
}

// 🚦 ROUTER: Cleaned up to prevent the "White Screen" fast-switching crash
function AppRoutes({ user }) {
  return (
    <Routes>
      
      {/* Auth Entry */}
      <Route path="/" element={user ? <Navigate to="/sales" /> : <Login />} />
      
      {/* Role Hubs (Protected) */}
      <Route path="/admin" element={<ProtectedRoute user={user}><AdminDashboard /></ProtectedRoute>} />
      <Route path="/sales" element={<ProtectedRoute user={user}><SalesDashboard /></ProtectedRoute>} />
      <Route path="/customer" element={<ProtectedRoute user={user}><CustomerDashboard /></ProtectedRoute>} /> 
      <Route path="/management" element={<ProtectedRoute user={user}><ManagementDashboard /></ProtectedRoute>} /> 
      
      {/* Core Sales Tools (Protected) */}
      <Route path="/user-dashboard" element={<ProtectedRoute user={user}><UserDashboard /></ProtectedRoute>} /> 
      <Route path="/kva-calc" element={<ProtectedRoute user={user}><KVACalculator /></ProtectedRoute>} />
      <Route path="/battery-calc" element={<ProtectedRoute user={user}><BatteryCalculator /></ProtectedRoute>} />
      <Route path="/recommendation" element={<ProtectedRoute user={user}><RecommendationEngine /></ProtectedRoute>} />
      
      {/* Admin Tools (Protected) */}
      <Route path="/catalog" element={<ProtectedRoute user={user}><ProductCatalog /></ProtectedRoute>} />
      <Route path="/users" element={<ProtectedRoute user={user}><UserManagement /></ProtectedRoute>} />
      <Route path="/invoices" element={<ProtectedRoute user={user}><MyInvoices /></ProtectedRoute>} />
      <Route path="/reports" element={<ProtectedRoute user={user}><RevenueReports /></ProtectedRoute>} />
      
      {/* Demo Placeholders (Protected) */}
      <Route path="/tracking" element={<ProtectedRoute user={user}><DemoPlaceholder title="Advanced Order Tracking" /></ProtectedRoute>} />
      <Route path="/regional" element={<ProtectedRoute user={user}><DemoPlaceholder title="Regional Data Analytics" /></ProtectedRoute>} />
      
      {/* Catch-all: Send lost users back to safety */}
      <Route path="*" element={<Navigate to="/" />} />
    </Routes>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // 🔐 Firebase Session Listener
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false); 
    });

    return () => unsubscribe();
  }, []);

  // Show a clean loader while Firebase checks the browser session
  if (loading) {
    return (
      <div className="h-screen w-screen bg-[#0f172a] flex flex-col items-center justify-center">
        <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
        <p className="text-slate-400 font-bold tracking-widest uppercase text-xs animate-pulse">Authenticating...</p>
      </div>
    );
  }

  return (
    <BrowserRouter>
      <AppRoutes user={user} />
    </BrowserRouter>
  );
}