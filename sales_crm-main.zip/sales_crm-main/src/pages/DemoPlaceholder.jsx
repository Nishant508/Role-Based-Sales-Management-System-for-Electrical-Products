import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { Sparkles, Construction } from "lucide-react";

export default function DemoPlaceholder({ title }) {
  return (
    <DashboardLayout>
      <div className="h-[75vh] flex flex-col items-center justify-center text-center max-w-2xl mx-auto px-6">
        <div className="bg-blue-50 p-6 rounded-[32px] mb-8 shadow-sm">
          <Sparkles size={48} className="text-blue-600" />
        </div>
        
        <h1 className="text-3xl md:text-4xl font-black text-slate-800 mb-4">{title}</h1>
        <p className="text-lg text-slate-500 font-medium mb-10 leading-relaxed">
          This module is fully mapped out in the platform's architecture but is locked for this specific presentation environment.
        </p>
        
        <div className="bg-white border border-slate-200 shadow-sm rounded-2xl p-6 w-full text-left flex items-start gap-4">
          <div className="bg-amber-100 p-2.5 rounded-xl text-amber-600 mt-0.5 shrink-0">
             <Construction size={20} />
          </div>
          <div>
            <h3 className="font-bold text-slate-800 text-lg">Pitch Note</h3>
            <p className="text-sm text-slate-500 mt-2 leading-relaxed font-medium">
              To keep the presentation focused on the core engineering algorithms and sales flow (KVA logic, Battery math, AI Recommendation Engine), we have hidden these administrative views. They use the same React + Firebase architecture as the primary dashboards.
            </p>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}