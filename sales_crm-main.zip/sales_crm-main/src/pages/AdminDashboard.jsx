import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import { Users, Server, AlertTriangle, Activity, Package, ArrowRight, ShieldCheck } from "lucide-react";
import { 
  LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend 
} from 'recharts';
import { db } from "../firebase";
import { collection, query, onSnapshot, orderBy, limit } from "firebase/firestore";

// Static Demo Data
const revenueData = [
  { month: 'Jan', revenue: 120 },
  { month: 'Feb', revenue: 180 },
  { month: 'Mar', revenue: 150 },
  { month: 'Apr', revenue: 280 },
  { month: 'May', revenue: 320 },
  { month: 'Jun', revenue: 410 },
];

const regionData = [
  { name: 'North (Delhi/NCR)', value: 45 },
  { name: 'South (Chennai/Blr)', value: 35 },
  { name: 'West (Mumbai/Pune)', value: 15 },
  { name: 'East (Kolkata)', value: 5 },
];

const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#8b5cf6'];

export default function AdminDashboard() {
  // 🚀 HOOKS MOVED INSIDE THE FUNCTION
  const [liveOrders, setLiveOrders] = useState([]);

  useEffect(() => {
    const q = query(collection(db, "leads"), orderBy("createdAt", "desc"), limit(5));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map(doc => ({
        id: doc.id.slice(0, 5).toUpperCase(),
        ...doc.data()
      }));
      setLiveOrders(orders);
    });

    return () => unsubscribe();
  }, []);

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8">
        
        {/* Page Header */}
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-bold text-slate-800 tracking-tight">Admin Control Center</h1>
            <p className="text-slate-500 font-medium mt-1">Power Infrastructure Management & Overview</p>
          </div>
          <div className="bg-emerald-50 text-emerald-700 px-4 py-2 rounded-xl border border-emerald-200 text-sm font-bold flex items-center gap-2 shadow-sm">
            <div className="w-2.5 h-2.5 bg-emerald-500 rounded-full animate-pulse"></div>
            System Live - India Region
          </div>
        </div>

        {/* Top KPI Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-blue-300 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Total Products</p>
                <p className="text-3xl font-black text-slate-800">124</p>
              </div>
              <div className="bg-blue-50 text-blue-600 p-3 rounded-xl"><Package size={20} /></div>
            </div>
            <p className="text-xs font-bold text-blue-600">+3 added this week</p>
          </div>
          
          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-emerald-300 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Active Deals</p>
                <p className="text-3xl font-black text-slate-800">₹4.2Cr</p>
              </div>
              <div className="bg-emerald-50 text-emerald-600 p-3 rounded-xl"><Activity size={20} /></div>
            </div>
            <p className="text-xs font-bold text-emerald-600">Across 18 opportunities</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-purple-300 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">Installed UPS Base</p>
                <p className="text-3xl font-black text-slate-800">1,842</p>
              </div>
              <div className="bg-purple-50 text-purple-600 p-3 rounded-xl"><Server size={20} /></div>
            </div>
            <p className="text-xs font-bold text-slate-500">Active units nationwide</p>
          </div>

          <div className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm relative overflow-hidden group hover:border-red-300 transition-all">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-1">AMC / Warranty Alerts</p>
                <p className="text-3xl font-black text-slate-800">14</p>
              </div>
              <div className="bg-red-50 text-red-600 p-3 rounded-xl"><AlertTriangle size={20} /></div>
            </div>
            <p className="text-xs font-bold text-red-500">Expiring in next 30 days</p>
          </div>
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h2 className="text-lg font-bold text-slate-800 mb-6">Revenue Trend (₹ Lakhs)</h2>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={revenueData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#e2e8f0" />
                  <XAxis dataKey="month" axisLine={false} tickLine={false} />
                  <YAxis axisLine={false} tickLine={false} tickFormatter={(val) => `₹${val}L`} />
                  <Tooltip contentStyle={{ borderRadius: '12px', border: 'none' }} />
                  <Line type="monotone" dataKey="revenue" stroke="#2563eb" strokeWidth={4} />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-slate-200 shadow-sm p-6">
            <h2 className="text-lg font-bold text-slate-800 mb-2">Orders by Region</h2>
            <div className="h-64 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={regionData} cx="50%" cy="45%" innerRadius={60} outerRadius={80} dataKey="value">
                    {regionData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Legend verticalAlign="bottom" height={36} />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Recent Pipeline Table - Now uses LIVE DATA */}
        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-slate-50/50">
            <h2 className="text-lg font-bold text-slate-800">Live Lead Feed</h2>
            <button className="text-sm font-bold text-blue-600 flex items-center gap-1 hover:text-blue-700">
              View All <ArrowRight size={16} />
            </button>
          </div>
          
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-500 font-bold text-xs uppercase tracking-wider border-b border-slate-200">
                <tr>
                  <th className="px-6 py-4">Lead ID</th>
                  <th className="px-6 py-4">Client Name</th>
                  <th className="px-6 py-4">Requirement</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {liveOrders.map((order, i) => (
                  <tr key={i} className="hover:bg-slate-50 transition-colors group">
                    <td className="px-6 py-4 font-bold text-slate-700">{order.id}</td>
                    <td className="px-6 py-4 font-bold text-slate-800">{order.clientName || 'Unnamed Lead'}</td>
                    <td className="px-6 py-4 font-medium text-slate-600">{order.kvaRequirement} kVA</td>
                    <td className="px-6 py-4">
                      <span className="bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-xs font-bold">
                        {order.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}