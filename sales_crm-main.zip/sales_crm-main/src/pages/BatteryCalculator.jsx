import React, { useState } from 'react';
import DashboardLayout from '../components/DashboardLayout';
import { ArrowLeft, Battery, Zap, Clock, CloudUpload, FileText, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { jsPDF } from "jspdf";
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

export default function BatteryCalculator() {
  const navigate = useNavigate();

  // State for calculator inputs
  const [capacity, setCapacity] = useState(10); // kVA
  const [load, setLoad] = useState(80); // %
  const [backupTime, setBackupTime] = useState(30); // minutes
  const [voltage, setVoltage] = useState(48); // VDC
  const [isSyncing, setIsSyncing] = useState(false);

  const voltageOptions = [12, 48, 96, 192];

  // --- Battery Math Calculations ---
  const powerFactor = 0.9;
  const actualLoadKVA = capacity * (load / 100);
  const actualLoadWatts = actualLoadKVA * 1000 * powerFactor;
  const dischargeCurrent = voltage > 0 ? (actualLoadWatts / voltage) : 0;
  const requiredAh = dischargeCurrent * (backupTime / 60);
  const recommendedAh = Math.ceil(requiredAh * 1.20); // 20% Safety Margin

  // --- 🚀 FIREBASE SYNC ---
  const handleSyncLead = async () => {
    setIsSyncing(true);
    try {
      await addDoc(collection(db, "leads"), {
        clientName: "Battery Spec Lead #" + Math.floor(1000 + Math.random() * 9000),
        kvaRequirement: capacity,
        backupRequirement: `${backupTime} mins`,
        recommendedAh: recommendedAh,
        voltage: voltage,
        status: "Technical Review",
        type: "Battery Calculator",
        createdAt: serverTimestamp(),
      });
      alert("🚀 Technical specs synced to 8V Cloud!");
    } catch (error) {
      console.error("Firebase Error:", error);
    } finally {
      setIsSyncing(false);
    }
  };

  // --- 📄 PDF GENERATION ---
  const generatePDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text("8V Electric - Battery Bank Analysis", 20, 30);
    doc.setFontSize(12);
    doc.text(`UPS System: ${capacity} kVA @ ${load}% Load`, 20, 50);
    doc.text(`Required Backup: ${backupTime} Minutes`, 20, 60);
    doc.text(`DC Bus Voltage: ${voltage} VDC`, 20, 70);
    doc.setDrawColor(37, 99, 235);
    doc.line(20, 75, 190, 75);
    doc.setFontSize(16);
    doc.text(`Recommended Battery Capacity: ${recommendedAh} Ah`, 20, 90);
    doc.text(`System Current: ${dischargeCurrent.toFixed(1)} Amps`, 20, 100);
    doc.save(`8V_Battery_Spec_${voltage}V.pdf`);
  };

  return (
    <DashboardLayout>
      <div className="max-w-6xl mx-auto pb-10">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/sales')} className="p-2.5 bg-white border border-slate-200 rounded-xl text-blue-600 hover:bg-blue-50 transition-all shadow-sm">
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-2xl font-black text-slate-800 tracking-tight flex items-center gap-2">
                <div className="bg-emerald-500 p-1.5 rounded-lg text-white"><Zap size={18} /></div>
                Battery Backup Calculator
              </h1>
              <p className="text-slate-500 text-sm font-medium">Precision Ah calculation for industrial battery banks</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT: Configuration */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-[32px] p-8 border border-slate-200 shadow-sm space-y-10">
              <h2 className="flex items-center gap-2 text-slate-800 font-black text-xs uppercase tracking-[.2em] border-b border-slate-100 pb-4">
                UPS System Configuration
              </h2>
              
              <div className="space-y-12">
                {/* Capacity */}
                <div>
                  <div className="flex justify-between items-end mb-4">
                    <label className="font-bold text-slate-700">UPS Capacity (kVA)</label>
                    <span className="text-2xl font-black text-blue-600">{capacity} kVA</span>
                  </div>
                  <input type="range" min="1" max="500" step="1" value={capacity} onChange={(e) => setCapacity(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600" />
                </div>

                {/* Load Slider */}
                <div>
                  <div className="flex justify-between items-end mb-4">
                    <label className="font-bold text-slate-700">Operational Load (%)</label>
                    <span className="text-2xl font-black text-emerald-600">{load}%</span>
                  </div>
                  <input type="range" min="10" max="100" step="5" value={load} onChange={(e) => setLoad(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-500" />
                  <p className="text-[10px] font-bold text-slate-400 mt-2">ACTUAL LOAD: {actualLoadKVA.toFixed(2)} kVA / {actualLoadWatts.toFixed(0)} Watts</p>
                </div>

                {/* Backup Time */}
                <div>
                  <div className="flex justify-between items-end mb-4">
                    <label className="font-bold text-slate-700">Required Backup Time (Min)</label>
                    <span className="text-2xl font-black text-blue-600">{backupTime} min</span>
                  </div>
                  <input type="range" min="5" max="240" step="5" value={backupTime} onChange={(e) => setBackupTime(Number(e.target.value))} className="w-full h-2 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-blue-600" />
                </div>

                {/* Voltage Selector */}
                <div>
                  <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-4">DC Bus Voltage (VDC)</label>
                  <div className="flex flex-wrap gap-4">
                    {voltageOptions.map(v => (
                      <button key={v} onClick={() => setVoltage(v)} className={`flex-1 py-4 rounded-2xl font-black text-lg transition-all ${voltage === v ? 'bg-[#0f172a] text-white shadow-xl' : 'bg-slate-50 text-slate-500 border border-slate-200 hover:bg-slate-100'}`}>
                        {v}V
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT: Results */}
          <div className="space-y-6">
            <div className="bg-[#16a34a] rounded-[32px] p-8 text-white shadow-xl relative overflow-hidden">
               <div className="relative z-10 space-y-6">
                  <div>
                    <p className="text-[10px] font-black text-green-200 uppercase tracking-[.2em] mb-1">Recommended Capacity</p>
                    <p className="text-5xl font-black">{recommendedAh} <span className="text-xl font-normal">Ah</span></p>
                    <p className="text-xs text-green-200/60 font-bold mt-2">Includes 20% safety margin</p>
                  </div>
                  
                  <div className="pt-6 border-t border-green-500/50">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-xs font-bold opacity-70 italic">Calculated Base</span>
                      <span className="font-black">{requiredAh.toFixed(1)} Ah</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-xs font-bold opacity-70 italic">Discharge Current</span>
                      <span className="font-black">{dischargeCurrent.toFixed(1)} A</span>
                    </div>
                  </div>

                  <div className="flex flex-col gap-3 pt-4">
                    <button onClick={handleSyncLead} disabled={isSyncing} className="w-full bg-white text-green-700 py-4 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-green-50 transition-all">
                      {isSyncing ? <Loader2 className="animate-spin" /> : <CloudUpload size={20} />}
                      {isSyncing ? "SYNCING..." : "SYNC TO CLOUD"}
                    </button>
                    <button onClick={generatePDF} className="w-full bg-green-700/50 text-white border border-green-400/30 py-4 rounded-2xl font-black flex items-center justify-center gap-2 hover:bg-green-700 transition-all">
                      <FileText size={20} /> GENERATE REPORT
                    </button>
                  </div>
               </div>
            </div>

            <div className="bg-[#0f172a] rounded-[24px] p-6 text-white text-center">
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Runtime</p>
               <p className="text-3xl font-black">{backupTime} <span className="text-sm font-normal text-slate-400">Minutes</span></p>
            </div>
          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}