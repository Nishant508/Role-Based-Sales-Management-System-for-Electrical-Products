import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { useNavigate } from "react-router-dom";
import { 
  Users, Target, FileText, TrendingUp,
  Calculator, Battery, Lightbulb, ArrowRight, Briefcase
} from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';

export default function SalesDashboard() {
  const navigate = useNavigate();

  const pipelineData = [
    { stage: 'Prospect', value: 180 },
    { stage: 'Qualified', value: 230 },
    { stage: 'Negotiation', value: 140 },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-6 pb-10">
        
        {/* ------------------------------------------------------------- */}
        {/* FIGMA HEADER CARD */}
        {/* ------------------------------------------------------------- */}
        <div className="bg-white rounded-[20px] p-6 md:p-8 border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)] flex flex-col lg:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-5">
            <div className="bg-[#10b981] p-4 rounded-2xl shadow-sm">
              <Briefcase className="text-white" size={28} />
            </div>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold text-slate-800 leading-tight">Sales & Engineering Dashboard</h1>
              <p className="text-slate-500 font-medium text-sm mt-1">UPS System Configurator & Sales Pipeline</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-3">
             <button onClick={() => navigate('/kva-calc')} className="flex items-center gap-2 bg-[#2563eb] text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-blue-700 transition-all shadow-sm">
               <Calculator size={18} /> KVA Calculator
             </button>
             <button onClick={() => navigate('/battery-calc')} className="flex items-center gap-2 bg-[#16a34a] text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-green-700 transition-all shadow-sm">
               <Battery size={18} /> Battery Calculator
             </button>
             <button onClick={() => navigate('/recommendation')} className="flex items-center gap-2 bg-[#4f46e5] text-white px-5 py-2.5 rounded-xl font-semibold text-sm hover:bg-indigo-700 transition-all shadow-sm">
               <Lightbulb size={18} /> Recommendation Engine
             </button>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* KPI CARDS (Matching Figma layout & colors) */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          
          <div className="bg-white p-6 rounded-[20px] border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">My Clients</p>
                <p className="text-4xl font-bold text-slate-800">42</p>
              </div>
              <div className="bg-slate-50 border border-slate-100 text-slate-600 p-2.5 rounded-xl"><Briefcase size={20} /></div>
            </div>
            <p className="text-xs font-bold text-blue-600">+15% <span className="text-slate-400 font-medium">vs last month</span></p>
          </div>

          <div className="bg-white p-6 rounded-[20px] border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Open Opportunities</p>
                <p className="text-4xl font-bold text-slate-800">18</p>
              </div>
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-500 p-2.5 rounded-xl"><Target size={20} /></div>
            </div>
            <p className="text-xs font-bold text-blue-600">+22% <span className="text-slate-400 font-medium">vs last month</span></p>
          </div>

          <div className="bg-white p-6 rounded-[20px] border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Proposals Generated</p>
                <p className="text-4xl font-bold text-slate-800">67</p>
              </div>
              <div className="bg-blue-50 border border-blue-100 text-blue-500 p-2.5 rounded-xl"><FileText size={20} /></div>
            </div>
            <p className="text-xs font-bold text-blue-600">+31% <span className="text-slate-400 font-medium">vs last month</span></p>
          </div>

          <div className="bg-white p-6 rounded-[20px] border border-slate-100 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
            <div className="flex justify-between items-start mb-4">
              <div>
                <p className="text-sm font-medium text-slate-500 mb-1">Pipeline Value</p>
                <p className="text-4xl font-bold text-slate-800">₹1.84Cr</p>
              </div>
              <div className="bg-slate-50 border border-slate-100 text-slate-700 p-2.5 rounded-xl"><TrendingUp size={20} /></div>
            </div>
            <p className="text-xs font-bold text-blue-600">+18% <span className="text-slate-400 font-medium">vs last month</span></p>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* SOLID COLORED ACTION CARDS */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          
          {/* Blue Card */}
          <div onClick={() => navigate('/kva-calc')} className="bg-[#1d4ed8] rounded-[20px] p-8 text-white shadow-md shadow-blue-200 flex flex-col justify-between min-h-[240px] cursor-pointer hover:-translate-y-1 transition-transform group">
            <div className="flex justify-between items-start">
              <h3 className="text-xl font-bold mb-1">KVA Load Calculator</h3>
              <Calculator size={24} className="opacity-70" />
            </div>
            <div>
              <p className="text-blue-100 text-sm mb-6 leading-relaxed">Calculate UPS capacity based on equipment load</p>
              <button className="flex items-center gap-2 font-bold text-sm text-white group-hover:gap-4 transition-all">
                Start Calculation <ArrowRight size={16} />
              </button>
            </div>
          </div>

          {/* Green Card */}
          <div onClick={() => navigate('/battery-calc')} className="bg-[#15803d] rounded-[20px] p-8 text-white shadow-md shadow-green-200 flex flex-col justify-between min-h-[240px] cursor-pointer hover:-translate-y-1 transition-transform group">
            <div className="flex justify-between items-start">
              <h3 className="text-xl font-bold mb-1">Battery Backup Calculator</h3>
              <Battery size={24} className="opacity-70" />
            </div>
            <div>
              <p className="text-green-100 text-sm mb-6 leading-relaxed">Calculate battery requirements for backup time</p>
              <button className="flex items-center gap-2 font-bold text-sm text-white group-hover:gap-4 transition-all">
                Start Calculation <ArrowRight size={16} />
              </button>
            </div>
          </div>

          {/* Purple Card */}
          <div onClick={() => navigate('/recommendation')} className="bg-[#7e22ce] rounded-[20px] p-8 text-white shadow-md shadow-purple-200 flex flex-col justify-between min-h-[240px] cursor-pointer hover:-translate-y-1 transition-transform group">
            <div className="flex justify-between items-start">
              <h3 className="text-xl font-bold mb-1">AI Recommendation Engine</h3>
              <Lightbulb size={24} className="opacity-70" />
            </div>
            <div>
              <p className="text-purple-100 text-sm mb-6 leading-relaxed">Intelligent UPS product recommendations</p>
              <button className="flex items-center gap-2 font-bold text-sm text-white group-hover:gap-4 transition-all">
                Launch Engine <ArrowRight size={16} />
              </button>
            </div>
          </div>
        </div>

        {/* ------------------------------------------------------------- */}
        {/* CHARTS */}
        {/* ------------------------------------------------------------- */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 bg-white rounded-[20px] border border-slate-100 p-8 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
            <h2 className="text-lg font-bold text-slate-800 mb-8 flex items-center gap-2">
              <TrendingUp size={20} className="text-blue-600"/> Revenue Pipeline by Stage (₹ Lakhs)
            </h2>
            <div className="h-64 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={pipelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
                  <XAxis dataKey="stage" stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} />
                  <YAxis stroke="#64748b" fontSize={12} tickLine={false} axisLine={false} tickFormatter={(val) => `₹${val}L`} />
                  <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{backgroundColor: '#fff', border: '1px solid #e2e8f0', borderRadius: '12px', color: '#0f172a', fontWeight: 'bold'}} />
                  <Bar dataKey="value" radius={[6, 6, 0, 0]} barSize={40}>
                    <Cell fill="#2563eb" />
                    <Cell fill="#10b981" />
                    <Cell fill="#f59e0b" />
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white rounded-[20px] border border-slate-100 p-8 shadow-[0_2px_10px_-3px_rgba(6,81,237,0.1)]">
             <h2 className="text-lg font-bold text-slate-800 mb-8">Deal Stages</h2>
             <div className="flex items-center justify-center h-64 text-slate-400 font-medium border-2 border-dashed border-slate-200 rounded-xl">
                Deal Stage Donut Chart
             </div>
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}