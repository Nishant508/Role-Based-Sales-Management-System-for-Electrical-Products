import React, { useState } from 'react';
import DashboardLayout from '../components/DashboardLayout';
import { ArrowLeft, Plus, Trash2, Zap, TrendingUp, CloudUpload, Loader2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

const EQUIPMENT_DATABASE = {
  "Workstation PC": 250,
  "Server Rack": 1500,
  "CCTV System": 150,
  "Network Switch": 100,
  "Industrial AC": 3500,
  "Laser Printer": 600,
  "Biometric System": 50
};

export default function KVACalculator() {
  const navigate = useNavigate();
  
  // States
  const [equipments, setEquipments] = useState([{ name: "Workstation PC", watts: 250, quantity: 1 }]);
  const [selectedEq, setSelectedEq] = useState("");
  const [phase, setPhase] = useState("Single Phase");
  const [isSyncing, setIsSyncing] = useState(false);

  // Logic Functions
  const handleAddEquipment = () => {
    if (!selectedEq) return;
    setEquipments([...equipments, { name: selectedEq, watts: EQUIPMENT_DATABASE[selectedEq], quantity: 1 }]);
    setSelectedEq("");
  };

  const updateQuantity = (index, value) => {
    const updated = [...equipments];
    updated[index].quantity = Math.max(1, Number(value) || 0);
    setEquipments(updated);
  };

  const removeEquipment = (index) => {
    setEquipments(equipments.filter((_, i) => i !== index));
  };

  // Calculations
  const totalWatts = equipments.reduce((sum, eq) => sum + (eq.watts * eq.quantity), 0);
  const totalKW = totalWatts / 1000;
  const powerFactor = 0.90;
  const calculatedKVA = totalKW > 0 ? (totalKW / powerFactor) : 0;
  const finalKVA = Math.ceil(calculatedKVA * 1.25); // 25% Margin rounded up

  // --- 🚀 FIREBASE SYNC FUNCTION ---
  const handleSaveLead = async () => {
    if (finalKVA === 0) return alert("Add some equipment first!");
    
    setIsSyncing(true);
    try {
      await addDoc(collection(db, "leads"), {
        clientName: "Enterprise Lead #" + Math.floor(1000 + Math.random() * 9000),
        kvaRequirement: finalKVA, 
        phase: phase, 
        status: "Processing",
        type: "KVA Calculator",
        createdAt: serverTimestamp(),
      });
      alert("🚀 Success! Lead synced to Admin Dashboard.");
    } catch (error) {
      console.error("Firebase Error:", error);
      alert("Error syncing to cloud. Check console.");
    } finally {
      setIsSyncing(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-5xl mx-auto pb-10">
        
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/sales')} className="p-2.5 bg-white border border-slate-200 rounded-xl text-blue-600 hover:bg-blue-50 transition-all shadow-sm">
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 tracking-tight flex items-center gap-2">
                <div className="bg-blue-600 p-1.5 rounded-lg text-white"><Zap size={18} /></div>
                KVA Load Calculator
              </h1>
              <p className="text-slate-500 text-sm font-medium">Calculate UPS capacity with 25% safety margin</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT: Inputs */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-[24px] p-6 border border-slate-200 shadow-sm">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Select Equipment</label>
                  <div className="flex gap-2">
                    <select 
                      value={selectedEq}
                      onChange={(e) => setSelectedEq(e.target.value)}
                      className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 outline-none focus:border-blue-500 font-bold text-slate-700"
                    >
                      <option value="">Choose type...</option>
                      {Object.keys(EQUIPMENT_DATABASE).map(eq => (
                        <option key={eq} value={eq}>{eq} ({EQUIPMENT_DATABASE[eq]}W)</option>
                      ))}
                    </select>
                    <button onClick={handleAddEquipment} className="bg-blue-600 text-white px-4 rounded-xl hover:bg-blue-700 transition-colors">
                      <Plus size={20} />
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">System Phase</label>
                  <select 
                    value={phase}
                    onChange={(e) => setPhase(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-700 outline-none"
                  >
                    <option>Single Phase</option>
                    <option>Three Phase</option>
                  </select>
                </div>
              </div>

              <div className="space-y-3">
                <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Equipment List</h3>
                {equipments.map((eq, index) => (
                  <div key={index} className="flex items-center justify-between bg-slate-50 p-4 rounded-2xl border border-slate-100">
                    <div className="w-1/3">
                      <p className="font-bold text-slate-800">{eq.name}</p>
                      <p className="text-[10px] text-blue-600 font-black uppercase tracking-tighter">Load: {eq.watts}W</p>
                    </div>
                    <div className="flex items-center gap-6">
                      <input 
                        type="number" 
                        value={eq.quantity} 
                        onChange={(e) => updateQuantity(index, e.target.value)} 
                        className="w-16 bg-white border border-slate-200 rounded-xl py-2 text-center font-black text-slate-800 outline-none" 
                      />
                      <p className="font-black text-slate-800 w-16 text-right">{eq.watts * eq.quantity}W</p>
                      <button onClick={() => removeEquipment(index)} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={18} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* RIGHT: Results */}
          <div className="space-y-6">
            <div className="bg-[#0f172a] rounded-[32px] p-8 text-white shadow-xl relative overflow-hidden">
               <div className="relative z-10 space-y-6">
                  <div>
                    <p className="text-[10px] font-black text-blue-400 uppercase tracking-[.2em] mb-1">Total Power Load</p>
                    <p className="text-4xl font-black">{totalKW.toFixed(2)} <span className="text-xl font-normal text-slate-400">kW</span></p>
                  </div>
                  
                  <div className="pt-6 border-t border-slate-800">
                    <p className="text-[10px] font-black text-emerald-400 uppercase tracking-[.2em] mb-1">Recommended UPS</p>
                    <p className="text-5xl font-black text-emerald-500">{finalKVA} <span className="text-2xl font-normal">kVA</span></p>
                    <p className="text-xs text-slate-500 font-bold mt-2">Safety Margin: 25% Included</p>
                  </div>

                  <button 
                    onClick={handleSaveLead}
                    disabled={isSyncing}
                    className="w-full bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-white py-4 rounded-2xl font-black flex items-center justify-center gap-3 transition-all mt-4 shadow-lg shadow-blue-900/50"
                  >
                    {isSyncing ? <Loader2 className="animate-spin" /> : <CloudUpload size={20} />}
                    {isSyncing ? "SYNCING..." : "SYNC TO ADMIN CLOUD"}
                  </button>
               </div>
               <div className="absolute top-[-20%] right-[-10%] w-64 h-64 bg-blue-600/10 blur-[80px] rounded-full"></div>
            </div>

            <div className="bg-white rounded-[24px] p-6 border border-slate-200">
              <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-4">Technical Details</h4>
              <div className="space-y-3">
                <div className="flex justify-between text-sm"><span className="font-bold text-slate-500">Power Factor</span><span className="font-black">0.90</span></div>
                <div className="flex justify-between text-sm"><span className="font-bold text-slate-500">System Phase</span><span className="font-black text-blue-600">{phase}</span></div>
              </div>
            </div>
          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}