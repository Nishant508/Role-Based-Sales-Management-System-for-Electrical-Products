import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import { Package, Plus, Trash2, Edit3, Save, X, Loader2, Database } from "lucide-react";
import { db } from "../firebase";
import { collection, addDoc, onSnapshot, deleteDoc, doc, serverTimestamp } from "firebase/firestore";

export default function ProductCatalog() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  
  // Form State
  const [newProd, setNewProd] = useState({
    name: "", id: "", price: "", maxKva: "", phase: "1-in / 1-out", efficiency: "94%"
  });

  // 🛰️ Fetch Products from Firebase
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "products"), (snapshot) => {
      setProducts(snapshot.docs.map(d => ({ id: d.id, ...d.data() })));
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  const handleAdd = async (e) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, "products"), { ...newProd, createdAt: serverTimestamp() });
      setShowAdd(false);
      setNewProd({ name: "", id: "", price: "", maxKva: "", phase: "1-in / 1-out", efficiency: "94%" });
    } catch (err) { console.error(err); }
  };

  const handleDelete = async (id) => {
    if(window.confirm("Delete this product from global catalog?")) {
      await deleteDoc(doc(db, "products", id));
    }
  };

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-6 pb-10">
        
        {/* Header */}
        <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm flex justify-between items-center">
          <div className="flex items-center gap-4">
            <div className="bg-slate-900 p-3 rounded-2xl text-white"><Database size={24}/></div>
            <div>
              <h1 className="text-2xl font-black text-slate-800 tracking-tight">Product Inventory</h1>
              <p className="text-slate-500 text-sm font-medium">Manage the global 8V Electric hardware database</p>
            </div>
          </div>
          <button 
            onClick={() => setShowAdd(!showAdd)}
            className="bg-blue-600 text-white px-6 py-3 rounded-xl font-black text-sm flex items-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100"
          >
            {showAdd ? <X size={18}/> : <Plus size={18}/>}
            {showAdd ? "CANCEL" : "ADD NEW PRODUCT"}
          </button>
        </div>

        {/* Add Product Form */}
        {showAdd && (
          <div className="bg-slate-900 rounded-[32px] p-8 text-white animate-in slide-in-from-top duration-300">
            <form onSubmit={handleAdd} className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <input placeholder="Model Name (e.g. 8V ProMax)" className="bg-slate-800 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500" onChange={e => setNewProd({...newProd, name: e.target.value})} required />
              <input placeholder="Price (e.g. ₹ 85,000)" className="bg-slate-800 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500" onChange={e => setNewProd({...newProd, price: e.target.value})} required />
              <input type="number" placeholder="Max kVA" className="bg-slate-800 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500" onChange={e => setNewProd({...newProd, maxKva: Number(e.target.value)})} required />
              <select className="bg-slate-800 border border-slate-700 p-3 rounded-xl outline-none" onChange={e => setNewProd({...newProd, phase: e.target.value})}>
                <option>1-in / 1-out</option>
                <option>3-in / 1-out</option>
                <option>3-in / 3-out</option>
              </select>
              <input placeholder="Efficiency %" className="bg-slate-800 border border-slate-700 p-3 rounded-xl outline-none focus:border-blue-500" onChange={e => setNewProd({...newProd, efficiency: e.target.value})} />
              <button type="submit" className="bg-emerald-500 hover:bg-emerald-600 text-white font-black rounded-xl">SAVE TO DATABASE</button>
            </form>
          </div>
        )}

        {/* Table View */}
        <div className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-left">
            <thead className="bg-slate-50 border-b border-slate-100">
              <tr>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Model & Spec</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Capacity</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest">Price</th>
                <th className="px-8 py-5 text-[10px] font-black text-slate-400 uppercase tracking-widest text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {products.map(p => (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-8 py-5">
                    <p className="font-black text-slate-800">{p.name}</p>
                    <p className="text-xs text-blue-600 font-bold">{p.phase} • {p.efficiency} Eff.</p>
                  </td>
                  <td className="px-8 py-5 font-black text-slate-600">{p.maxKva} kVA</td>
                  <td className="px-8 py-5 font-black text-slate-900">{p.price}</td>
                  <td className="px-8 py-5 text-right">
                    <button onClick={() => handleDelete(p.id)} className="text-red-400 hover:text-red-600 p-2"><Trash2 size={18}/></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {loading && <div className="p-20 flex justify-center"><Loader2 className="animate-spin text-blue-600"/></div>}
        </div>
      </div>
    </DashboardLayout>
  );
}