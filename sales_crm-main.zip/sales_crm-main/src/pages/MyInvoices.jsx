import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { FileText, Download, CheckCircle2, Clock } from "lucide-react";

const invoices = [
  { id: "INV-8091", amount: "₹ 1,45,000", date: "Oct 12, 2025", status: "Paid", product: "8V ProX Online" },
  { id: "INV-8092", amount: "₹ 35,000", date: "Oct 15, 2025", status: "Pending", product: "AMC Renewal" },
];

export default function MyInvoices() {
  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm flex items-center gap-4">
          <div className="bg-blue-600 p-3 rounded-xl text-white shadow-lg"><FileText size={24} /></div>
          <div>
            <h1 className="text-2xl font-bold text-slate-800">My Invoices</h1>
            <p className="text-slate-500 text-sm font-medium">Billing history and payment documents</p>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs border-b border-slate-200">
              <tr>
                <th className="px-8 py-5">Invoice ID</th>
                <th className="px-8 py-5">Product / Service</th>
                <th className="px-8 py-5">Date</th>
                <th className="px-8 py-5">Amount</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {invoices.map((inv, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors">
                  <td className="px-8 py-5 font-bold text-slate-700">{inv.id}</td>
                  <td className="px-8 py-5 font-medium text-slate-600">{inv.product}</td>
                  <td className="px-8 py-5 text-slate-500">{inv.date}</td>
                  <td className="px-8 py-5 font-black text-slate-800">{inv.amount}</td>
                  <td className="px-8 py-5">
                    <span className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold ${inv.status === 'Paid' ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
                      {inv.status === 'Paid' ? <CheckCircle2 size={14}/> : <Clock size={14}/>} {inv.status}
                    </span>
                  </td>
                  <td className="px-8 py-5 text-right">
                    <button className="text-blue-600 hover:text-blue-800 font-bold flex items-center gap-1 ml-auto">
                      <Download size={16}/> PDF
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}