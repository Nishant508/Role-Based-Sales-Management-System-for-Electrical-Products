import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { Users, Shield, MoreVertical, CheckCircle2 } from "lucide-react";

const team = [
  { name: "Vanshika Sharma", role: "Super Admin", email: "vanshika@8velectric.in", status: "Active", lastLogin: "2 mins ago" },
  { name: "Ranjit Grewal", role: "Sales Manager", email: "ranjit@8velectric.in", status: "Active", lastLogin: "1 hour ago" },
  { name: "Amit Kumar", role: "Sales Executive", email: "amit@8velectric.in", status: "Away", lastLogin: "5 hours ago" },
];

export default function UserManagement() {
  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="flex justify-between items-center bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="bg-blue-600 p-3 rounded-xl text-white shadow-lg"><Users size={24} /></div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">User Management</h1>
              <p className="text-slate-500 text-sm font-medium">Manage team roles and access permissions</p>
            </div>
          </div>
          <button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-blue-700 transition-all">Add New User</button>
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs border-b border-slate-200">
              <tr>
                <th className="px-8 py-5">Team Member</th>
                <th className="px-8 py-5">Role</th>
                <th className="px-8 py-5">Status</th>
                <th className="px-8 py-5">Last Login</th>
                <th className="px-8 py-5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {team.map((user, i) => (
                <tr key={i} className="hover:bg-slate-50 transition-colors">
                  <td className="px-8 py-5">
                    <p className="font-bold text-slate-800">{user.name}</p>
                    <p className="text-xs text-slate-400 font-medium">{user.email}</p>
                  </td>
                  <td className="px-8 py-5">
                    <span className="bg-slate-100 text-slate-600 px-3 py-1 rounded-lg text-xs font-bold border border-slate-200">{user.role}</span>
                  </td>
                  <td className="px-8 py-5">
                    <div className="flex items-center gap-2">
                      <div className={`w-2 h-2 rounded-full ${user.status === 'Active' ? 'bg-emerald-500 animate-pulse' : 'bg-amber-400'}`}></div>
                      <span className="font-bold text-slate-700">{user.status}</span>
                    </div>
                  </td>
                  <td className="px-8 py-5 text-slate-500 font-medium">{user.lastLogin}</td>
                  <td className="px-8 py-5 text-right"><button className="text-slate-400 hover:text-slate-600"><MoreVertical size={18}/></button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </DashboardLayout>
  );
}