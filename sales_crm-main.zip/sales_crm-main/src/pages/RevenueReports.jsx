import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { TrendingUp, Download, BarChart3, ArrowUpRight } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const detailedRevenue = [
  { category: 'Online UPS', revenue: 450, growth: '+12%' },
  { category: 'Modular UPS', revenue: 890, growth: '+24%' },
  { category: 'BESS Storage', revenue: 620, growth: '+45%' },
  { category: 'Services', revenue: 180, growth: '+5%' },
];

export default function RevenueReports() {
  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8">
        <div className="flex justify-between items-center bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex items-center gap-4">
            <div className="bg-blue-600 p-3 rounded-xl text-white shadow-lg"><BarChart3 size={24} /></div>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Financial Reports</h1>
              <p className="text-slate-500 text-sm font-medium">Product-wise revenue breakdown and growth</p>
            </div>
          </div>
          <button className="flex items-center gap-2 bg-slate-900 text-white px-6 py-2.5 rounded-xl font-bold text-sm shadow-md hover:bg-slate-800 transition-all"><Download size={18} /> Export PDF</button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {detailedRevenue.map((item, i) => (
            <div key={i} className="bg-white p-6 rounded-2xl border border-slate-200 shadow-sm group hover:border-blue-300 transition-all">
              <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">{item.category}</p>
              <p className="text-3xl font-black text-slate-800">₹{item.revenue}L</p>
              <div className="flex items-center gap-1 text-emerald-600 font-bold text-xs mt-2">
                <ArrowUpRight size={14} /> {item.growth} <span className="text-slate-400 font-medium">YoY</span>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl border border-slate-200 p-8 shadow-sm h-96">
          <h3 className="font-bold text-slate-800 mb-8">Revenue Comparison (₹ Lakhs)</h3>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={detailedRevenue}>
              <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
              <XAxis dataKey="category" axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
              <YAxis axisLine={false} tickLine={false} tick={{fill: '#64748b', fontSize: 12}} />
              <Tooltip cursor={{fill: '#f8fafc'}} contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}} />
              <Bar dataKey="revenue" fill="#2563eb" radius={[8, 8, 0, 0]} barSize={50} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>
    </DashboardLayout>
  );
}