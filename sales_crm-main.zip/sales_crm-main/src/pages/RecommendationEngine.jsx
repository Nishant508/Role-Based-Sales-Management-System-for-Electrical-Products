import React, { useState } from 'react';
import DashboardLayout from '../components/DashboardLayout';
import { 
  ArrowLeft, Lightbulb, CheckCircle2, XCircle, 
  AlertCircle, FileText, Download, Target, Sparkles, CloudUpload, Loader2 
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { jsPDF } from "jspdf";
import { db } from "../firebase";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";

// 8V Electric Enterprise UPS Database
const PRODUCT_CATALOG = [
  {
    id: 'UPS-001',
    name: '8V ProX Online UPS',
    type: 'Online Double Conversion',
    maxKva: 20,
    phase: '3-in / 1-out',
    warranty: '2 Years',
    price: '₹ 1,45,000',
    specs: { thdi: '< 3%', efficiency: '94%', isolation: 'Built-in' }
  },
  {
    id: 'UPS-002',
    name: '8V Enterprise Modular',
    type: 'Modular Online',
    maxKva: 60,
    phase: '3-in / 3-out',
    warranty: '3 Years AMC',
    price: '₹ 4,20,000',
    specs: { thdi: '< 2%', efficiency: '96%', isolation: 'Optional' }
  },
  {
    id: 'UPS-003',
    name: '8V EcoLine Interactive',
    type: 'Line Interactive',
    maxKva: 5,
    phase: '1-in / 1-out',
    warranty: '1 Year',
    price: '₹ 35,000',
    specs: { thdi: '< 5%', efficiency: '90%', isolation: 'None' }
  }
];

export default function RecommendationEngine() {
  const navigate = useNavigate();
  const [isSyncing, setIsSyncing] = useState(false);

  // Customer Requirements State
  const [reqKva, setReqKva] = useState(15);
  const [reqPhase, setReqPhase] = useState('3-in / 1-out');
  const [reqEfficiency, setReqEfficiency] = useState(93);

  // --- 📄 PDF GENERATOR LOGIC ---
  const generatePDF = (product) => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.setTextColor(15, 23, 42); // Navy Blue
    doc.text("8V Electric - Official Quotation", 20, 30);
    
    doc.setDrawColor(226, 232, 240);
    doc.line(20, 35, 190, 35);

    doc.setFontSize(12);
    doc.text(`Reference ID: ${product.id}`, 20, 45);
    doc.text(`Date: ${new Date().toLocaleDateString()}`, 20, 52);

    doc.setFontSize(16);
    doc.text("Product Specifications", 20, 70);
    doc.setFontSize(12);
    doc.text(`Model Name: ${product.name}`, 20, 80);
    doc.text(`Type: ${product.type}`, 20, 88);
    doc.text(`Phase: ${product.phase}`, 20, 96);
    doc.text(`Efficiency: ${product.specs.efficiency}`, 20, 104);
    
    doc.setFontSize(18);
    doc.setTextColor(37, 99, 235); // Blue
    doc.text(`Dealer Price: ${product.price}`, 20, 120);

    doc.setFontSize(10);
    doc.setTextColor(100, 116, 139);
    doc.text("This is an AI-generated proposal for 8V Electric Dealers.", 20, 150);
    
    doc.save(`${product.id}_Proposal.pdf`);
  };

  // --- 🚀 FIREBASE SYNC LOGIC ---
  const handleSyncToLeads = async (product) => {
    setIsSyncing(true);
    try {
      await addDoc(collection(db, "leads"), {
        clientName: "AI Recommendation: " + product.name,
        kvaRequirement: reqKva,
        recommendedProduct: product.name,
        price: product.price,
        status: "Proposal Sent",
        type: "AI Engine",
        createdAt: serverTimestamp(),
      });
      alert(`✅ ${product.name} saved to your Sales Hub!`);
    } catch (error) {
      console.error("Firebase Error:", error);
      alert("Error syncing to cloud.");
    } finally {
      setIsSyncing(false);
    }
  };

  // Gap Analysis 
  const analyzeGaps = (product) => {
    const gaps = [];
    const matches = [];
    if (product.maxKva >= reqKva) matches.push(`Capacity covers ${reqKva}kVA load`);
    else gaps.push(`Underpowered (Max ${product.maxKva}kVA)`);

    if (product.phase === reqPhase) matches.push(`Phase matches (${reqPhase})`);
    else gaps.push(`Phase mismatch (Has ${product.phase})`);

    const prodEff = parseInt(product.specs.efficiency);
    if (prodEff >= reqEfficiency) matches.push(`High Efficiency (${product.specs.efficiency})`);
    else gaps.push(`Below target efficiency (${product.specs.efficiency})`);

    const totalCriteria = matches.length + gaps.length;
    return { matches, gaps, score: (matches.length / totalCriteria) * 100 };
  };

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto pb-10 space-y-6">
        
        {/* Header Section */}
        <div className="bg-white rounded-[24px] p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-6">
          <div className="flex items-center gap-4">
            <button onClick={() => navigate('/sales')} className="p-2.5 bg-slate-50 border border-slate-200 rounded-xl text-slate-500 hover:text-blue-600 transition-all">
              <ArrowLeft size={20} />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800 flex items-center gap-2">
                <Sparkles className="text-blue-600" size={24} /> AI Recommendation Engine
              </h1>
              <p className="text-slate-500 text-sm font-medium">Intelligent UPS selection & deep gap analysis</p>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
          
          {/* LEFT PANEL: Requirements */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-[24px] p-8 border border-slate-200 shadow-sm sticky top-6 space-y-8">
              <div className="flex items-center gap-2 text-slate-800 font-bold border-b border-slate-100 pb-4">
                <Target size={18} className="text-blue-600" /> Client Requirements
              </div>
              
              <div className="space-y-6">
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Target Load (kVA)</label>
                  <input type="number" value={reqKva} onChange={(e) => setReqKva(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-700 outline-none focus:border-blue-500" />
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Phase Setup</label>
                  <select value={reqPhase} onChange={(e) => setReqPhase(e.target.value)} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-700 outline-none">
                    <option>1-in / 1-out</option>
                    <option>3-in / 1-out</option>
                    <option>3-in / 3-out</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">Min Efficiency (%)</label>
                  <input type="number" value={reqEfficiency} onChange={(e) => setReqEfficiency(Number(e.target.value))} className="w-full bg-slate-50 border border-slate-200 rounded-xl px-4 py-3 font-bold text-slate-700 outline-none" />
                </div>
              </div>
            </div>
          </div>

          {/* RIGHT PANEL: Product Match Cards */}
          <div className="lg:col-span-3 space-y-6">
            {PRODUCT_CATALOG.map(product => {
              const { matches, gaps, score } = analyzeGaps(product);
              
              return (
                <div key={product.id} className="bg-white rounded-[24px] p-8 border border-slate-200 shadow-sm flex flex-col md:flex-row gap-8 relative overflow-hidden group">
                  
                  {/* Identity */}
                  <div className="md:w-1/3 border-r border-slate-100 pr-8 flex flex-col justify-between">
                    <div>
                      <div className="flex items-center gap-3 mb-4">
                        <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">{product.id}</span>
                        {score === 100 && <span className="bg-emerald-100 text-emerald-700 text-[10px] font-black px-3 py-1 rounded-full uppercase">Perfect Match</span>}
                      </div>
                      <h3 className="text-2xl font-black text-slate-800 leading-tight group-hover:text-blue-600 transition-colors">{product.name}</h3>
                      <p className="text-sm text-slate-500 font-bold mt-2 uppercase">{product.type}</p>
                    </div>
                    
                    <div className="mt-8 pt-6 border-t border-slate-100">
                      <p className="text-[10px] text-slate-400 font-black uppercase tracking-widest mb-1">Distributor Price</p>
                      <p className="text-3xl font-black text-blue-600">{product.price}</p>
                    </div>
                  </div>

                  {/* Analysis & Actions */}
                  <div className="md:w-2/3 flex flex-col justify-between">
                    <div>
                      <div className="flex justify-between items-end mb-6">
                         <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest">Specification Analysis</h4>
                         <span className="text-xs font-bold text-blue-600">Match: {score.toFixed(0)}%</span>
                      </div>
                      
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {matches.map((match, i) => (
                          <div key={`m-${i}`} className="flex items-center gap-3 bg-emerald-50/40 border border-emerald-100/50 p-4 rounded-2xl">
                            <CheckCircle2 size={16} className="text-emerald-500" />
                            <span className="text-sm font-bold text-slate-700">{match}</span>
                          </div>
                        ))}
                        {gaps.map((gap, i) => (
                          <div key={`g-${i}`} className="flex items-center gap-3 bg-red-50/40 border border-red-100/50 p-4 rounded-2xl">
                            <XCircle size={16} className="text-red-500" />
                            <span className="text-sm font-bold text-red-900">{gap}</span>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* ACTION BUTTONS: Now located correctly on each product */}
                    <div className="mt-8 flex flex-col sm:flex-row gap-3">
                       <button 
                         onClick={() => generatePDF(product)}
                         className="flex-1 bg-white border border-slate-200 text-slate-700 py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-slate-50 transition-all shadow-sm"
                       >
                         <Download size={18} /> Download Proposal
                       </button>
                       <button 
                         onClick={() => handleSyncToLeads(product)}
                         disabled={isSyncing}
                         className="flex-1 bg-blue-600 text-white py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 hover:bg-blue-700 transition-all shadow-lg shadow-blue-100 disabled:opacity-50"
                       >
                         {isSyncing ? <Loader2 className="animate-spin" /> : <CloudUpload size={18} />}
                         {isSyncing ? "SYNCING..." : "Sync to CRM"}
                       </button>
                    </div>
                  </div>

                </div>
              )
            })}
          </div>

        </div>
      </div>
    </DashboardLayout>
  );
}