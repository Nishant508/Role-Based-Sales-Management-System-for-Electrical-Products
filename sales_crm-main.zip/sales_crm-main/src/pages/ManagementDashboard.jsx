import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import { TrendingUp, BarChart3, PieChart as PieIcon, Target, Loader2, IndianRupee } from "lucide-react";
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, Legend
} from 'recharts';
import { db } from "../firebase";
import { collection, onSnapshot, query } from "firebase/firestore";

const COLORS = ['#2563eb', '#10b981', '#f59e0b', '#8b5cf6'];

export default function ManagementDashboard() {
  const [leadData, setLeadData] = useState([]);
  const [loading, setLoading] = useState(true);

  // 🛰️ Live Data Aggregation
  useEffect(() => {
    const unsubscribe = onSnapshot(collection(db, "leads"), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setLeadData(data);
      setLoading(false);
    }, (error) => {
      console.error("Firebase Error:", error);
      setLoading(false);
    });
    return () => unsubscribe();
  }, []);

  // 🛡️ PROTECTED CALCULATION LOGIC
  const totalRevenue = leadData.reduce((sum, lead) => {
    // Ensure price is a string before replacing, default to "0"
    const priceStr = String(lead.price || "0").replace(/[^0-9]/g, '');
    const priceValue = parseInt(priceStr) || 0;
    return sum + priceValue;
  }, 0);

  const avgDealSize = leadData.length > 0 ? totalRevenue / leadData.length : 0;

  // Formatting data for the Area Chart
  const chartData = [
    { month: 'Jan', sales: 4.2 },
    { month: 'Feb', sales: 3.8 },
    { month: 'Mar', sales: 5.1 },
    // April shows live data from Firestore (scaled to Lakhs)
    { month: 'Apr', sales: totalRevenue > 0 ? totalRevenue / 100000 : 0.5 }, 
  ];

  // 🛑 TOP-LEVEL LOADING GUARD (Prevents White Screen)
  if (loading) {
    return (
      <DashboardLayout>
        <div className="h-[60vh] flex flex-col items-center justify-center">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-slate-400 font-black uppercase tracking-widest text-xs animate-pulse">
            Synchronizing Executive Intelligence...
          </p>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8 pb-10">
        
        {/* Header */}
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight">Executive Insights</h1>
            <p className="text-slate-500 font-medium mt-1">Live Revenue & Market Performance Analytics</p>
          </div>
          <div className="bg-emerald-50 text-emerald-700 px-5 py-2 rounded-xl text-xs font-black border border-emerald-100 flex items-center gap-2 shadow-sm">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
            8V CLOUD SYNC ACTIVE
          </div>
        </div>

        {/* Real-Time KPIs */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <StatBox 
            label="Total Pipeline" 
            value={`₹${(totalRevenue / 10000000).toFixed(2)}Cr`} 
            detail="Gross Opportunity" 
            color="blue" 
          />
          <StatBox 
            label="Avg Deal Value" 
            value={`₹${(avgDealSize / 1000).toFixed(1)}K`} 
            detail="Per Recommendation" 
            color="emerald" 
          />
          <StatBox 
            label="Total Leads" 
            value={leadData.length} 
            detail="Active Funnel" 
            color="amber" 
          />
          <StatBox 
            label="Conversion" 
            value="32%" 
            detail="Target: 40%" 
            color="purple" 
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Revenue Growth Area Chart */}
          <div className="lg:col-span-2 bg-white rounded-[32px] border border-slate-200 p-8 shadow-sm">
            <div className="flex justify-between items-center mb-8">
              <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest flex items-center gap-2">
                <TrendingUp size={18} className="text-blue-600" /> Revenue Trajectory
              </h3>
              <span className="text-[10px] font-black text-slate-400">UNIT: ₹ LAKHS</span>
            </div>
            <div className="h-72 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="colorSales" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#2563eb" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#2563eb" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="month" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 11, fontWeight: '800'}} 
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fill: '#94a3b8', fontSize: 11, fontWeight: '800'}} 
                    tickFormatter={(val) => `₹${val}L`}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '20px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)' }} 
                    cursor={{ stroke: '#2563eb', strokeWidth: 2, strokeDasharray: '5 5' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="sales" 
                    stroke="#2563eb" 
                    strokeWidth={4} 
                    fill="url(#colorSales)" 
                    animationDuration={1500}
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Regional Share Donut */}
          <div className="bg-white rounded-[32px] border border-slate-200 p-8 shadow-sm relative overflow-hidden">
            <h3 className="font-black text-slate-800 mb-8 text-sm uppercase tracking-widest">Pipeline Health</h3>
            <div className="h-72 w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie 
                    data={[
                      {name: 'Qualified Leads', value: leadData.length}, 
                      {name: 'Market Bench', value: Math.max(5, 20 - leadData.length)}
                    ]} 
                    cx="50%" cy="50%" 
                    innerRadius={70} 
                    outerRadius={95} 
                    paddingAngle={8} 
                    dataKey="value"
                  >
                    <Cell fill="#2563eb" stroke="none" />
                    <Cell fill="#f1f5f9" stroke="none" />
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                <p className="text-3xl font-black text-slate-800">{leadData.length}</p>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tighter">Total Leads</p>
              </div>
            </div>
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between text-[10px] font-black uppercase">
                <span className="text-slate-400">Data Integrity</span>
                <span className="text-emerald-500">100% Verified</span>
              </div>
              <div className="w-full bg-slate-100 h-1 rounded-full">
                <div className="bg-emerald-500 h-1 rounded-full w-full"></div>
              </div>
            </div>
          </div>
        </div>

      </div>
    </DashboardLayout>
  );
}

function StatBox({ label, value, detail, color }) {
  const colors = {
    blue: 'bg-blue-600',
    emerald: 'bg-emerald-500',
    amber: 'bg-amber-500',
    purple: 'bg-purple-600'
  };
  return (
    <div className="bg-white p-6 rounded-[28px] border border-slate-200 shadow-sm group hover:border-blue-400 transition-all hover:shadow-xl hover:shadow-blue-50">
      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
      <p className="text-3xl font-black text-slate-800 tracking-tight">{value}</p>
      <div className="flex items-center gap-2 mt-4 pt-4 border-t border-slate-50">
        <div className={`h-2 w-2 rounded-full ${colors[color]} animate-pulse`}></div>
        <p className="text-[10px] font-bold text-slate-400 italic">{detail}</p>
      </div>
    </div>
  );
}