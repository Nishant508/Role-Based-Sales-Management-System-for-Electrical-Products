import React from "react";
import DashboardLayout from "../components/DashboardLayout";
import { 
  Package, ShieldCheck, Clock, CheckCircle2, 
  Wrench, FileText, Send, Zap, ArrowRight 
} from "lucide-react";

export default function CustomerDashboard() {
  const installedAssets = [
    { id: '8V-UPS-910', model: '8V ProX Online (20kVA)', status: 'Active', load: '62%' },
    { id: '8V-BAT-402', model: 'BESS Lithium Pack', status: 'Healthy', health: '98%' },
  ];

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8 pb-10">
        
        {/* 1. Welcome Header */}
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black text-slate-800 tracking-tight">Client Portal</h1>
            <p className="text-slate-500 font-medium">TechPark Noida • Account #8V-10293</p>
          </div>
          <div className="flex gap-3">
            <button className="bg-white border border-slate-200 text-slate-700 px-5 py-2.5 rounded-xl font-bold text-sm hover:bg-slate-50">View History</button>
            <button className="bg-blue-600 text-white px-6 py-2.5 rounded-xl font-black text-sm shadow-lg shadow-blue-100">Request Service</button>
          </div>
        </div>

        {/* 2. Key Metrics Row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <StatCard label="Active Assets" value="02" detail="All Systems Live" icon={<Package size={20} className="text-blue-600"/>} />
          <StatCard label="Active Order" value="ORD-9102" detail="Out for Delivery" icon={<Clock size={20} className="text-amber-500"/>} />
          <StatCard label="Warranty" value="Tier 1" detail="Premium Partner" icon={<ShieldCheck size={20} className="text-emerald-500"/>} />
        </div>

        {/* 3. Main Content Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* LEFT: Assets & Tracking */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm overflow-hidden">
              <div className="p-6 border-b border-slate-100 flex justify-between items-center">
                <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest">Active Infrastructure</h3>
                <Zap size={18} className="text-blue-600" />
              </div>
              <div className="divide-y divide-slate-50">
                {installedAssets.map(asset => (
                  <div key={asset.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 bg-slate-100 rounded-2xl flex items-center justify-center text-slate-400">
                        <Package size={24} />
                      </div>
                      <div>
                        <p className="font-black text-slate-800">{asset.model}</p>
                        <p className="text-[10px] font-bold text-slate-400 uppercase tracking-tight">SN: {asset.id}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <span className="bg-emerald-50 text-emerald-600 px-3 py-1 rounded-full text-[10px] font-black uppercase">
                        {asset.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white rounded-[32px] border border-slate-200 shadow-sm p-8">
              <h3 className="font-black text-slate-800 text-sm uppercase tracking-widest mb-8">Delivery Progress</h3>
              <div className="flex justify-between relative">
                <div className="absolute top-4 left-0 w-full h-0.5 bg-slate-100 -z-0"></div>
                <TrackingNode label="Placed" date="Apr 2" active />
                <TrackingNode label="Shipped" date="Apr 5" active />
                <TrackingNode label="In Transit" date="Today" pulsing />
                <TrackingNode label="Delivery" date="Pending" />
              </div>
            </div>
          </div>

          {/* RIGHT: Sidebar Support & Invoices */}
          <div className="space-y-6">
            {/* COMPACT Support Widget */}
            <div className="bg-[#0f172a] rounded-[32px] p-6 text-white shadow-xl relative overflow-hidden">
              <div className="relative z-10">
                <h4 className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-4">Dedicated Support</h4>
                <div className="flex items-center gap-3 mb-6">
                  <img src="https://ui-avatars.com/api/?name=Ranjit+Grewal&background=2563eb&color=fff" className="w-10 h-10 rounded-xl" alt="Engineer" />
                  <div>
                    <p className="text-sm font-black text-white">Ranjit Grewal</p>
                    <p className="text-[10px] text-slate-500 font-bold">Field Engineer</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <input placeholder="Quick message..." className="bg-slate-800 text-xs p-3 rounded-xl flex-1 outline-none border border-slate-700 focus:border-blue-500" />
                  <button className="bg-blue-600 p-3 rounded-xl"><Send size={16} /></button>
                </div>
              </div>
            </div>

            {/* Recent Invoices Card */}
            <div className="bg-white rounded-[32px] border border-slate-200 p-6">
              <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Recent Billing</h4>
              <div className="space-y-4">
                <InvoiceRow id="INV-902" amount="₹1,45,000" date="Oct 12" />
                <InvoiceRow id="INV-881" amount="₹32,500" date="Sep 28" />
              </div>
              <button className="w-full mt-6 text-blue-600 font-black text-xs uppercase flex items-center justify-center gap-2">
                All Invoices <ArrowRight size={14} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </DashboardLayout>
  );
}

// Sub-components for cleaner code
function StatCard({ label, value, detail, icon }) {
  return (
    <div className="bg-white p-6 rounded-[28px] border border-slate-200 shadow-sm flex items-center justify-between">
      <div>
        <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{label}</p>
        <p className="text-2xl font-black text-slate-800">{value}</p>
        <p className="text-[10px] font-bold text-slate-500 mt-1">{detail}</p>
      </div>
      <div className="bg-slate-50 p-3 rounded-xl border border-slate-100">{icon}</div>
    </div>
  );
}

function TrackingNode({ label, date, active, pulsing }) {
  return (
    <div className="relative z-10 flex flex-col items-center">
      <div className={`h-8 w-8 rounded-full border-4 border-white shadow-sm flex items-center justify-center ${active ? 'bg-blue-600' : 'bg-slate-100'} ${pulsing ? 'animate-pulse bg-blue-500' : ''}`}>
        {active && <CheckCircle2 size={12} className="text-white" />}
      </div>
      <p className={`text-[10px] font-black mt-2 uppercase ${active ? 'text-slate-800' : 'text-slate-400'}`}>{label}</p>
      <p className="text-[9px] font-bold text-slate-400">{date}</p>
    </div>
  );
}

function InvoiceRow({ id, amount, date }) {
  return (
    <div className="flex justify-between items-center py-2">
      <div>
        <p className="text-xs font-black text-slate-800">{id}</p>
        <p className="text-[9px] font-bold text-slate-400">{date}</p>
      </div>
      <p className="text-xs font-black text-blue-600">{amount}</p>
    </div>
  );
}