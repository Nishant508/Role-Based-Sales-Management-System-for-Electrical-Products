import React, { useState, useEffect } from "react";
import DashboardLayout from "../components/DashboardLayout";
import { Inbox, Zap, Clock, ChevronRight, Loader2 } from "lucide-react";
import { db } from "../firebase";
import { collection, query, onSnapshot, orderBy } from "firebase/firestore";

export default function UserDashboard() {
  const [leads, setLeads] = useState([]);
  const [loading, setLoading] = useState(true);

  // 🛰️ REAL-TIME FIREBASE LISTENER (Made Bulletproof)
  useEffect(() => {
    const q = query(collection(db, "leads"), orderBy("createdAt", "desc"));
    
    const unsubscribe = onSnapshot(q, (snapshot) => {
      try {
        const leadsData = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        }));
        setLeads(leadsData);
        setLoading(false); // Data parsed successfully, turn off loader
      } catch (err) {
        console.error("Data Parsing Error:", err);
        setLoading(false); // Turn off loader even if it fails, so it doesn't spin forever
      }
    }, (error) => {
      console.error("Firebase Connection Error:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // 🛡️ SAFE DATE FORMATTER (Fixes the infinite loading crash)
  const formatDate = (timestamp) => {
    if (!timestamp || typeof timestamp.toDate !== 'function') return "Just Now";
    return timestamp.toDate().toLocaleDateString();
  };

  return (
    <DashboardLayout>
      <div className="max-w-7xl mx-auto space-y-8 pb-10">
        
        {/* Header Section */}
        <div className="bg-white rounded-[24px] p-8 border border-slate-200 shadow-sm flex justify-between items-center">
          <div className="flex items-center gap-5">
            <div className="bg-blue-600 p-4 rounded-2xl text-white shadow-lg shadow-blue-100">
              <Inbox size={28} />
            </div>
            <div>
              <h1 className="text-3xl font-black text-slate-800 tracking-tight">Sales Inbox</h1>
              <p className="text-slate-500 font-medium mt-1">Manage your active leads and calculations</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-xs font-black text-slate-400 uppercase tracking-[.2em] mb-1">Total Assignments</p>
            <p className="text-3xl font-black text-blue-600">{leads.length}</p>
          </div>
        </div>

        {/* Content Area */}
        <div className="space-y-4">
          <h2 className="text-sm font-black text-slate-400 uppercase tracking-widest px-2">Recent Assignments</h2>
          
          {loading ? (
            <div className="flex flex-col items-center justify-center py-20 bg-white rounded-[32px] border border-dashed border-slate-300">
              <Loader2 className="text-blue-600 animate-spin mb-4" size={40} />
              <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px]">Syncing with 8V Cloud...</p>
            </div>
          ) : leads && leads.length === 0 ? (
            <div className="text-center py-20 bg-white rounded-[32px] border border-dashed border-slate-300">
              <p className="text-slate-400 font-bold">No leads found. Go to KVA Calculator to create one!</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-4">
              {leads.map((lead) => (
                <div key={lead.id} className="bg-white p-6 rounded-[24px] border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-200 transition-all flex flex-col md:flex-row items-center justify-between gap-6 group cursor-pointer">
                  
                  <div className="flex items-center gap-6 w-full md:w-auto">
                    <div className="h-14 w-14 bg-slate-50 rounded-2xl flex items-center justify-center text-blue-600 border border-slate-100 group-hover:bg-blue-50 transition-colors">
                      <Zap size={24} />
                    </div>
                    <div>
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">{lead.id.slice(0, 8)}</p>
                      <h3 className="text-xl font-black text-slate-800">{lead.clientName || "Direct Inquiry"}</h3>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="flex items-center gap-1 text-xs font-bold text-slate-500">
                          <Clock size={12} /> {formatDate(lead.createdAt)}
                        </span>
                        <span className="bg-emerald-50 text-emerald-600 text-[10px] font-black px-2 py-0.5 rounded-md border border-emerald-100">
                          {lead.type || "KVA LEAD"}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-10 w-full md:w-auto justify-between md:justify-end border-t md:border-t-0 pt-4 md:pt-0 border-slate-100">
                    <div className="text-right">
                      <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Requirement</p>
                      {/* Dynamically handles KVA leads vs Battery Ah leads */}
                      <p className="text-2xl font-black text-slate-800">
                        {lead.kvaRequirement || lead.recommendedAh || 0} 
                        <span className="text-sm font-normal text-slate-400"> {lead.recommendedAh ? 'Ah' : 'kVA'}</span>
                      </p>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      <div className="bg-blue-50 text-blue-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-tight">
                        {lead.status || "Pending"}
                      </div>
                      <button className="p-3 bg-slate-50 rounded-xl text-slate-400 group-hover:text-blue-600 group-hover:bg-blue-50 transition-all">
                        <ChevronRight size={20} />
                      </button>
                    </div>
                  </div>

                </div>
              ))}
            </div>
          )}
        </div>

      </div>
    </DashboardLayout>
  );
}