// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
//import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";


//export const auth = getAuth();
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyBhrAqZ4GGCZH9KI1pfEYb61JYQxqHbvTs",
    authDomain: "electricsoftware-2afed.firebaseapp.com",
    projectId: "electricsoftware-2afed",
    storageBucket: "electricsoftware-2afed.firebasestorage.app",
    messagingSenderId: "736033565165",
    appId: "1:736033565165:web:be23ac714e97aa8bed9fe4",
    measurementId: "G-XYKE2DKJG3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
//const analytics = getAnalytics(app);
export const auth = getAuth(app);
export const db = getFirestore(app);